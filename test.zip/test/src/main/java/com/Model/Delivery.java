package com.Model;

import java.sql.Date;
import java.sql.Time;

public class Delivery {
    protected String trackingNo;
    protected String sender;
    protected String receiver;
    protected int noOfParcel;
    protected Date deliveredDate;
    protected String courierID;

    public Delivery(String trackingNo, String sender, String receiver, int noOfParcel, Date deliveredDate, String courierID) {
        this.trackingNo = trackingNo;
        this.sender = sender;
        this.receiver = receiver;
        this.noOfParcel = noOfParcel;
        this.deliveredDate = deliveredDate;
        this.courierID = courierID;
    }

    public String getTrackingNo() {
        return trackingNo;
    }

    public void setTrackingNo(String trackingNo) {
        this.trackingNo = trackingNo;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public String getReceiver() {
        return receiver;
    }

    public void setReceiver(String receiver) {
        this.receiver = receiver;
    }

    public int getNoOfParcel() {
        return noOfParcel;
    }

    public void setNoOfParcel(int noOfParcel) {
        this.noOfParcel = noOfParcel;
    }

    public Date getDeliveredDate() {
        return deliveredDate;
    }

    public void setDeliveredDate(Date deliveredDate) {
        this.deliveredDate = deliveredDate;
    }

    public String getCourierID() {
        return courierID;
    }

    public void setCourierID(String courierID) {
        this.courierID = courierID;
    }

}