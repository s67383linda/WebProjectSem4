/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.Model;

/**
 *
 * @author rynaa
 */
public class ShippingForm {
    protected String shippingID;
    protected String studID;
    protected String sender;
    protected String receiver;
    protected String address;
    protected Double weight;
    
    public ShippingForm() {}
    
    public ShippingForm(String shippingID, String studID, String sender, String receiver, String address, Double weight){
        super();
        this.shippingID = shippingID;
        this.studID = studID;
        this.sender = sender;
        this.receiver = receiver;
        this.address = address;
        this.weight = weight;
    }

    public String getShippingID() {
        return shippingID;
    }

    public void setShippingID(String shippingID) {
        this.shippingID = shippingID;
    }

    public String getStudID() {
        return studID;
    }

    public void setStudID(String studID) {
        this.studID = studID;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public String getReceiver() {
        return receiver;
    }

    public void setReceiver(String receiver) {
        this.receiver = receiver;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Double getWeight() {
        return weight;
    }

    public void setWeight(Double weight) {
        this.weight = weight;
    }
}
