package com.Model;

import java.sql.Date;

public class ParcelList {
    protected String parcelID;
    protected String trackingNo;
    protected String description;
    protected Double charge;
    protected Double weight;
    protected Date deliveredDate;
    protected String studID;

    public ParcelList() {}

    public ParcelList(String parcelID, String trackingNo, String description, Double charge, Double weight, Date deliveredDate, String studID) {
        super();
        this.parcelID = parcelID;
        this.trackingNo = trackingNo;
        this.description = description;
        this.charge = charge;
        this.weight = weight;
        this.deliveredDate = deliveredDate;
        this.studID = studID;
    }

    public String getParcelID() {
        return parcelID;
    }

    public void setParcelID(String parcelID) {
        this.parcelID = parcelID;
    }

    public String getTrackingNo() {
        return trackingNo;
    }

    public void setTrackingNo(String trackingNo) {
        this.trackingNo = trackingNo;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Double getCharge() {
        return charge;
    }

    public void setCharge(Double charge) {
        this.charge = charge;
    }

    public Double getWeight() {
        return weight;
    }

    public void setWeight(Double weight) {
        this.weight = weight;
    }

    public Date getDeliveredDate() {
        return deliveredDate;
    }

    public void setDeliveredDate(Date deliveredDate) {
        this.deliveredDate = deliveredDate;
    }
 
    public String getStudID() {
        return studID;
    }

    public void setStudID(String studID) {
        this.studID = studID;
    }
}
