package com.Model;


public class Payment {
    protected String paymentID;
    protected String staffID;
    protected String parcelID;
    protected Double charge;
    protected String typeOfCharge;
    
    public Payment(){}
    
    public Payment (String paymentID, String staffID, String parcelID, Double charge, String typeOfCharge){
        super();
        this.paymentID = paymentID;
        this.staffID = staffID;
        this.parcelID = parcelID;
        this.charge = charge;
        this.typeOfCharge = typeOfCharge;
    }

    public String getPaymentID() {
        return paymentID;
    }

    public void setPaymentID(String paymentID) {
        this.paymentID = paymentID;
    }

    public String getStaffID() {
        return staffID;
    }

    public void setStaffID(String staffID) {
        this.staffID = staffID;
    }

    public String getParcelID() {
        return parcelID;
    }

    public void setParcelID(String parcelID) {
        this.parcelID = parcelID;
    }

    public Double getCharge() {
        return charge;
    }

    public void setCharge(Double charge) {
        this.charge = charge;
    }

    public String getTypeOfCharge() {
        return typeOfCharge;
    }

    public void setTypeOfCharge(String typeOfCharge) {
        this.typeOfCharge = typeOfCharge;
    }
    
    
}
