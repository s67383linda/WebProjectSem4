package com.WEB;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Date;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.RequestDispatcher;

import com.DAO.ParcelListDAO;
import com.Model.ParcelList;

@WebServlet("/parcel/*")
public class ParcelListServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private ParcelListDAO parcelListDAO;

    public void init() {
        parcelListDAO = new ParcelListDAO();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getPathInfo();

        try {
            switch (action) {
                case "/new":
                    showNewForm(request, response);
                    break;
                case "/insert":
                    insertParcelList(request, response);
                    break;
                case "/delete":
                    deleteParcelList(request, response);
                    break;
                case "/edit":
                    showEditForm(request, response);
                    break;
                case "/update":
                    updateParcelList(request, response);
                    break;
                case "/list":
                    listParcelList(request, response);
                    break;
                default:
                    listParcelList(request, response);
                    break;
            }
        } catch (SQLException | ParseException ex) {
            throw new ServletException(ex);
        }
    }

    private void listParcelList(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        List<ParcelList> listParcelList = parcelListDAO.selectAllParcelList();
        request.setAttribute("listParcelList", listParcelList);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/parcelList.jsp");
        dispatcher.forward(request, response);
    }

    private void showNewForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("/parcelListForm.jsp");
        dispatcher.forward(request, response);
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        String parcelID = request.getParameter("parcelID");
        ParcelList existingParcelList = parcelListDAO.selectParcelList(parcelID);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/parcelListForm.jsp");
        request.setAttribute("parcelList", existingParcelList);
        dispatcher.forward(request, response);
    }

    private void insertParcelList(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ParseException {
        String parcelID = request.getParameter("parcelID");
        String trackingNo = request.getParameter("trackingNo");
        String description = request.getParameter("description");
        Double charge = Double.valueOf(request.getParameter("charge"));
        Double weight = Double.valueOf(request.getParameter("weight"));
        Date deliveredDate = new SimpleDateFormat("yyyy-MM-dd").parse(request.getParameter("deliveredDate"));
        String studID = request.getParameter("studID");
        ParcelList newParcelList = new ParcelList(parcelID, trackingNo, description, charge, weight, new java.sql.Date(deliveredDate.getTime()), studID);
        parcelListDAO.insertParcelList(newParcelList);
        response.sendRedirect("list");
    }

    private void updateParcelList(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ParseException {
        String parcelID = request.getParameter("parcelID");
        String trackingNo = request.getParameter("trackingNo");
        String description = request.getParameter("description");
        Double charge = Double.valueOf(request.getParameter("charge"));
        Double weight = Double.valueOf(request.getParameter("weight"));
        Date deliveredDate = new SimpleDateFormat("yyyy-MM-dd").parse(request.getParameter("deliveredDate"));
        String studID = request.getParameter("studID");
        ParcelList updateParcelList = new ParcelList(parcelID, trackingNo, description, charge, weight, new java.sql.Date(deliveredDate.getTime()), studID);
        parcelListDAO.updateParcelList(updateParcelList);
        response.sendRedirect("list");
    }

    private void deleteParcelList(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        String parcelID = request.getParameter("parcelID");
        parcelListDAO.deleteParcelList(parcelID);
        response.sendRedirect("list");
    }
}
