package com.WEB;

import com.DAO.ShippingFormDAO;
import com.Model.ShippingForm;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;

@WebServlet("/shipping/*")
public class ShippingFormServlet extends HttpServlet {
    private ShippingFormDAO shippingFormDAO;

    public void init() {
        shippingFormDAO = new ShippingFormDAO();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getPathInfo();

        try {
            switch (action) {
                case "/new":
                    showNewForm(request, response);
                    break;
                case "/insert":
                    insertShippingForm(request, response);
                    break;
                case "/delete":
                    deleteShippingForm(request, response);
                    break;
                case "/edit":
                    showEditForm(request, response);
                    break;
                case "/update":
                    updateShippingForm(request, response);
                    break;
                default:
                    listShippingForms(request, response);
                    break;
            }
        } catch (SQLException | ParseException ex) {
            throw new ServletException(ex);
        }
    }

    private void listShippingForms(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        List<ShippingForm> listShippingForm = shippingFormDAO.selectAllShippingForms();
        request.setAttribute("listShippingForm", listShippingForm);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/shippingFormList.jsp");
        dispatcher.forward(request, response);
    }

    private void showNewForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("/shippingForm.jsp");
        dispatcher.forward(request, response);
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        String shippingID = request.getParameter("shippingID");
        ShippingForm existingShippingForm = shippingFormDAO.selectShippingForm(shippingID);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/shippingForm.jsp");
        request.setAttribute("shippingForm", existingShippingForm);
        dispatcher.forward(request, response);
    }

    private void insertShippingForm(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ParseException {
        String shippingID = request.getParameter("shippingID");
        String studID = request.getParameter("studID");
        String sender = request.getParameter("sender");
        String receiver = request.getParameter("receiver");
        String address = request.getParameter("address");
        Double weight = Double.valueOf(request.getParameter("weight"));
        ShippingForm newShippingForm = new ShippingForm(shippingID, studID, sender, receiver, address, weight);
        shippingFormDAO.insertShippingForm(newShippingForm);
        response.sendRedirect("list");
    }

    private void updateShippingForm(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ParseException {
        String shippingID = request.getParameter("shippingID");
        String studID = request.getParameter("studID");
        String sender = request.getParameter("sender");
        String receiver = request.getParameter("receiver");
        String address = request.getParameter("address");
        Double weight = Double.valueOf(request.getParameter("weight"));
        ShippingForm updateShippingForm = new ShippingForm(shippingID, studID, sender, receiver, address, weight);
        shippingFormDAO.updateShippingForm(updateShippingForm);
        response.sendRedirect("list");
    }

    private void deleteShippingForm(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        String shippingID = request.getParameter("shippingID");
        shippingFormDAO.deleteShippingForm(shippingID);
        response.sendRedirect("list");
    }
}
