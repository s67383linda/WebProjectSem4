package com.WEB;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.RequestDispatcher;

import com.DAO.DeliveryDAO;
import com.Model.Delivery;
import java.text.SimpleDateFormat;
import java.util.Date;

@WebServlet("/delivery/*")
public class DeliveryServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private DeliveryDAO deliveryDAO;

    public void init() {
        deliveryDAO = new DeliveryDAO();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getPathInfo();

        try {
            switch (action) {
                case "/new":
                    showNewForm(request, response);
                    break;
                case "/insert":
                    insertDelivery(request, response);
                    break;
                case "/delete":
                    deleteDelivery(request, response);
                    break;
                case "/edit":
                    showEditForm(request, response);
                    break;
                case "/update":
                    updateDelivery(request, response);
                    break;
                case "/list":
                    listDelivery(request, response);
                    break;
                default:
                    listDelivery(request, response);
                    break;
            }
        } catch (SQLException | ParseException ex) {
            throw new ServletException(ex);
        }
    }

    private void listDelivery(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        List<Delivery> listDeliveryList = deliveryDAO.selectAllDelivery();
        request.setAttribute("listDeliveryList", listDeliveryList);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/DeliveryList.jsp");
        dispatcher.forward(request, response);
    }

    private void showNewForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("/DeliveryForm.jsp");
        dispatcher.forward(request, response);
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        String trackingNo = request.getParameter("trackingNo");
        Delivery existingDelivery = deliveryDAO.selectDelivery(trackingNo);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/DeliveryForm.jsp");
        request.setAttribute("delivery", existingDelivery);
        dispatcher.forward(request, response);
    }

    private void insertDelivery(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ParseException {
        String trackingNo = request.getParameter("trackingNo");
        String sender = request.getParameter("sender");
        String receiver = request.getParameter("receiver");
        int noOfParcel = Integer.parseInt(request.getParameter("noOfParcel"));
        Date deliveredDate = new SimpleDateFormat("yyyy-MM-dd").parse(request.getParameter("deliveredDate"));
        String courierID = request.getParameter("courierID");
        Delivery newDelivery = new Delivery(trackingNo, sender, receiver, noOfParcel, new java.sql.Date(deliveredDate.getTime()), courierID);
        deliveryDAO.insertDelivery(newDelivery);
        response.sendRedirect("list");
    }

    private void updateDelivery(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ParseException {
        String trackingNo = request.getParameter("trackingNo");
        String sender = request.getParameter("sender");
        String receiver = request.getParameter("receiver");
        int noOfParcel = Integer.parseInt(request.getParameter("noOfParcel"));
        Date deliveredDate = new SimpleDateFormat("yyyy-MM-dd").parse(request.getParameter("deliveredDate"));
        String courierID = request.getParameter("courierID");
        Delivery delivery = new Delivery(trackingNo, sender, receiver, noOfParcel, new java.sql.Date(deliveredDate.getTime()), courierID);
        deliveryDAO.updateDelivery(delivery);
        response.sendRedirect("list");
    }

    private void deleteDelivery(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        String trackingNo = request.getParameter("trackingNo");
        deliveryDAO.deleteDelivery(trackingNo);
        response.sendRedirect("list");
    }
}
