package com.WEB;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.RequestDispatcher;

import com.DAO.PaymentDAO;
import com.Model.Payment;

@WebServlet("/payment/*")
public class PaymentServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private PaymentDAO paymentDAO;

    public void init() {
        paymentDAO = new PaymentDAO();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getPathInfo();

        try {
            switch (action) {
                case "/new":
                    showNewForm(request, response);
                    break;
                case "/insert":
                    insertPayment(request, response);
                    break;
                case "/delete":
                    deletePayment(request, response);
                    break;
                case "/edit":
                    showEditForm(request, response);
                    break;
                case "/update":
                    updatePayment(request, response);
                    break;
                default:
                    listPayments(request, response);
                    break;
            }
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }
    }

    private void listPayments(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        List<Payment> listPayments = paymentDAO.selectAllPayments();
        request.setAttribute("listPayments", listPayments);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/payment.jsp");
        dispatcher.forward(request, response);
    }

    private void showNewForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("/paymentForm.jsp");
        dispatcher.forward(request, response);
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        String paymentID = request.getParameter("paymentID");
        Payment existingPayment = paymentDAO.selectPayment(paymentID);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/paymentForm.jsp");
        request.setAttribute("payment", existingPayment);
        dispatcher.forward(request, response);
    }

    private void insertPayment(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        String paymentID = request.getParameter("paymentID");
        String staffID = request.getParameter("staffID");
        String parcelID = request.getParameter("parcelID");
        Double charge = Double.valueOf(request.getParameter("charge"));
        String typeOfCharge = request.getParameter("typeOfCharge");
        Payment newPayment = new Payment(paymentID, staffID, parcelID, charge, typeOfCharge);
        paymentDAO.insertPayment(newPayment);
        response.sendRedirect("list");
    }

    private void updatePayment(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        String paymentID = request.getParameter("paymentID");
        String staffID = request.getParameter("staffID");
        String parcelID = request.getParameter("parcelID");
        Double charge = Double.valueOf(request.getParameter("charge"));
        String typeOfCharge = request.getParameter("typeOfCharge");
        Payment updatePayment = new Payment(paymentID, staffID, parcelID, charge, typeOfCharge);
        paymentDAO.updatePayment(updatePayment);
        response.sendRedirect("list");
    }

    private void deletePayment(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        String paymentID = request.getParameter("paymentID");
        paymentDAO.deletePayment(paymentID);
        response.sendRedirect("list");
    }
}
