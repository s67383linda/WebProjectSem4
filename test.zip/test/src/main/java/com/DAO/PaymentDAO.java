package com.DAO;

import com.Model.Payment;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PaymentDAO {
    private final String jdbcURL = "jdbc:mysql://localhost:3306/parcelmanagementsystem";
    private final String jdbcUsername = "root";
    private final String jdbcPassword = "admin";

    private static final String INSERT_PAYMENT_SQL = "INSERT INTO payment (paymentID, staffID, parcelID, charge, typeOfCharge) VALUES (?, ?, ?, ?, ?);";
    private static final String SELECT_PAYMENT_BY_PAYMENTID = "SELECT paymentID, staffID, parcelID, charge, typeOfCharge FROM payment WHERE paymentID =?;";
    private static final String SELECT_ALL_PAYMENTS = "SELECT * FROM payment";
    private static final String DELETE_PAYMENT_SQL = "DELETE FROM payment WHERE paymentID = ?;";
    private static final String UPDATE_PAYMENT_SQL = "UPDATE payment SET staffID = ?, parcelID = ?, charge = ?, typeOfCharge = ? WHERE paymentID = ?;";

    public PaymentDAO() {}

    protected Connection getConnection() {
        Connection connection = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
            System.out.println("Database connected successfully.");
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return connection;
    }

    public void insertPayment(Payment payment) throws SQLException {
        try (Connection connection = getConnection(); 
             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_PAYMENT_SQL)) {
            preparedStatement.setString(1, payment.getPaymentID());
            preparedStatement.setString(2, payment.getStaffID());
            preparedStatement.setString(3, payment.getParcelID());
            preparedStatement.setDouble(4, payment.getCharge());
            preparedStatement.setString(5, payment.getTypeOfCharge());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            printSQLException(e);
        }
    }

    public Payment selectPayment(String paymentID) {
        Payment payment = null;
        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_PAYMENT_BY_PAYMENTID)) {
            preparedStatement.setString(1, paymentID);
            ResultSet rs = preparedStatement.executeQuery();
            if (rs.next()) {
                String staffID = rs.getString("staffID");
                String parcelID = rs.getString("parcelID");
                double charge = rs.getDouble("charge");
                String typeOfCharge = rs.getString("typeOfCharge");
                payment = new Payment(paymentID, staffID, parcelID, charge, typeOfCharge);
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return payment;
    }

    public List<Payment> selectAllPayments() {
        List<Payment> payments = new ArrayList<>();
        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_PAYMENTS)) {
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                String paymentID = rs.getString("paymentID");
                String staffID = rs.getString("staffID");
                String parcelID = rs.getString("parcelID");
                double charge = rs.getDouble("charge");
                String typeOfCharge = rs.getString("typeOfCharge");
                payments.add(new Payment(paymentID, staffID, parcelID, charge, typeOfCharge));
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return payments;
    }

    public boolean deletePayment(String paymentID) throws SQLException {
        boolean rowDeleted;
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(DELETE_PAYMENT_SQL)) {
            statement.setString(1, paymentID);
            rowDeleted = statement.executeUpdate() > 0;
        }
        return rowDeleted;
    }

    public boolean updatePayment(Payment payment) throws SQLException {
        boolean rowUpdated;
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(UPDATE_PAYMENT_SQL)) {
            statement.setString(1, payment.getStaffID());
            statement.setString(2, payment.getParcelID());
            statement.setDouble(3, payment.getCharge());
            statement.setString(4, payment.getTypeOfCharge());
            statement.setString(5, payment.getPaymentID());
            rowUpdated = statement.executeUpdate() > 0;
        }
        return rowUpdated;
    }

    private void printSQLException(SQLException ex) {
        for (Throwable e : ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }
}
