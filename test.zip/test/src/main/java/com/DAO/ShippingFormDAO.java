package com.DAO;

import com.Model.ShippingForm;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ShippingFormDAO {
    private final String jdbcURL = "jdbc:mysql://localhost:3306/parcelmanagementsystem";
    private final String jdbcUsername = "root";
    private final String jdbcPassword = "admin";

    private static final String INSERT_SHIPPINGFORM_SQL = "INSERT INTO shippingForm (shippingID, studID, sender, receiver, address, weight) VALUES (?, ?, ?, ?, ?, ?);";
    private static final String SELECT_SHIPPINGFORM_BY_SHIPPINGID = "SELECT shippingID, studID, sender, receiver, address, weight FROM shippingForm WHERE shippingID = ?;";
    private static final String SELECT_ALL_SHIPPINGFORM = "SELECT * FROM shippingForm";
    private static final String DELETE_SHIPPINGFORM_SQL = "DELETE FROM shippingForm WHERE shippingID = ?;";
    private static final String UPDATE_SHIPPINGFORM_SQL = "UPDATE shippingForm SET studID = ?, sender = ?, receiver = ?, address = ?, weight = ? WHERE shippingID = ?;";

    public ShippingFormDAO() {}

    protected Connection getConnection() {
        Connection connection = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
            System.out.println("Database connected successfully.");
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return connection;
    }

    public void insertShippingForm(ShippingForm shippingForm) throws SQLException {
        System.out.println(INSERT_SHIPPINGFORM_SQL);
        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_SHIPPINGFORM_SQL)) {
            preparedStatement.setString(1, shippingForm.getShippingID());
            preparedStatement.setString(2, shippingForm.getStudID());
            preparedStatement.setString(3, shippingForm.getSender());
            preparedStatement.setString(4, shippingForm.getReceiver());
            preparedStatement.setString(5, shippingForm.getAddress());
            preparedStatement.setDouble(6, shippingForm.getWeight());
            System.out.println(preparedStatement);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            printSQLException(e);
        }
    }

    public ShippingForm selectShippingForm(String shippingID) {
        ShippingForm shippingForm = null;
        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_SHIPPINGFORM_BY_SHIPPINGID)) {
            preparedStatement.setString(1, shippingID);
            System.out.println(preparedStatement);
            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                String studID = rs.getString("studID");
                String sender = rs.getString("sender");
                String receiver = rs.getString("receiver");
                String address = rs.getString("address");
                Double weight = rs.getDouble("weight");
                shippingForm = new ShippingForm(shippingID, studID, sender, receiver, address, weight);
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return shippingForm;
    }

    public List<ShippingForm> selectAllShippingForms() {
        List<ShippingForm> shippingForms = new ArrayList<>();
        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_SHIPPINGFORM)) {
            System.out.println(preparedStatement);
            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                String shippingID = rs.getString("shippingID");
                String studID = rs.getString("studID");
                String sender = rs.getString("sender");
                String receiver = rs.getString("receiver");
                String address = rs.getString("address");
                Double weight = rs.getDouble("weight");
                shippingForms.add(new ShippingForm(shippingID, studID, sender, receiver, address, weight));
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return shippingForms;
    }

    public boolean deleteShippingForm(String shippingID) throws SQLException {
        boolean rowDeleted;
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(DELETE_SHIPPINGFORM_SQL)) {
            statement.setString(1, shippingID);
            rowDeleted = statement.executeUpdate() > 0;
        }
        return rowDeleted;
    }

    public boolean updateShippingForm(ShippingForm shippingForm) throws SQLException {
        boolean rowUpdated;
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(UPDATE_SHIPPINGFORM_SQL)) {
            statement.setString(1, shippingForm.getStudID());
            statement.setString(2, shippingForm.getSender());
            statement.setString(3, shippingForm.getReceiver());
            statement.setString(4, shippingForm.getAddress());
            statement.setDouble(5, shippingForm.getWeight());
            statement.setString(6, shippingForm.getShippingID());

            rowUpdated = statement.executeUpdate() > 0;
        }
        return rowUpdated;
    }

    private void printSQLException(SQLException ex) {
        for (Throwable e : ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }
}
