package com.DAO;

import com.Model.Delivery;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DeliveryDAO {
    private final String jdbcURL = "jdbc:mysql://localhost:3306/parcelmanagementsystem";
    private final String jdbcUsername = "root";
    private final String jdbcPassword = "admin";

    private static final String INSERT_DELIVERY_SQL = "INSERT INTO deliverydetails (trackingNo, sender, receiver, noOfParcel, time, courierID) VALUES (?, ?, ?, ?, ?, ?)";
    private static final String SELECT_DELIVERY_BY_TRACKINGNO = "SELECT trackingNo, sender, receiver, noOfParcel, time, courierID FROM deliverydetails WHERE trackingNo = ?";
    private static final String SELECT_ALL_DELIVERY = "SELECT * FROM deliverydetails";
    private static final String DELETE_DELIVERY_SQL = "DELETE FROM deliverydetails WHERE trackingNo = ?";
    private static final String UPDATE_DELIVERY_SQL = "UPDATE deliverydetails SET sender = ?, receiver = ?, noOfParcel = ?, time = ?, courierID = ? WHERE trackingNo = ?";

    

    protected Connection getConnection() {
        Connection connection = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
            System.out.println("Database connected successfully.");
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return connection;
    }

    public void insertDelivery(Delivery delivery) throws SQLException {
        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_DELIVERY_SQL)) {
            preparedStatement.setString(1, delivery.getTrackingNo());
            preparedStatement.setString(2, delivery.getSender());
            preparedStatement.setString(3, delivery.getReceiver());
            preparedStatement.setInt(4, delivery.getNoOfParcel());
            preparedStatement.setDate(5, delivery.getDeliveredDate());
            preparedStatement.setString(6, delivery.getCourierID());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            printSQLException(e);
        }
    }

    public Delivery selectDelivery(String trackingNo) {
        Delivery delivery = null;
        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_DELIVERY_BY_TRACKINGNO)) {
            preparedStatement.setString(1, trackingNo);
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                String sender = rs.getString("sender");
                String receiver = rs.getString("receiver");
                int noOfParcel = rs.getInt("noOfParcel");
                Date deliveredDate = rs.getDate("deliveredDate");
                String courierID = rs.getString("courierID");
                delivery = new Delivery(trackingNo, sender, receiver, noOfParcel, deliveredDate, courierID);
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return delivery;
    }

    public List<Delivery> selectAllDelivery() {
        List<Delivery> deliveryList = new ArrayList<>();
        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_DELIVERY)) {
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                String trackingNo = rs.getString("trackingNo");
                String sender = rs.getString("sender");
                String receiver = rs.getString("receiver");
                int noOfParcel = rs.getInt("noOfParcel");
                Date deliveredDate = rs.getDate("deliveredDate");
                String courierID = rs.getString("courierID");
                deliveryList.add(new Delivery(trackingNo, sender, receiver, noOfParcel, deliveredDate, courierID));
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return deliveryList;
    }

    public boolean deleteDelivery(String trackingNo) throws SQLException {
        boolean rowDeleted;
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(DELETE_DELIVERY_SQL)) {
            statement.setString(1, trackingNo);
            rowDeleted = statement.executeUpdate() > 0;
        }
        return rowDeleted;
    }

    public boolean updateDelivery(Delivery delivery) throws SQLException {
        boolean rowUpdated;
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(UPDATE_DELIVERY_SQL)) {
            statement.setString(1, delivery.getSender());
            statement.setString(2, delivery.getReceiver());
            statement.setInt(3, delivery.getNoOfParcel());
            statement.setDate(4, delivery.getDeliveredDate());
            statement.setString(5, delivery.getCourierID());
            statement.setString(6, delivery.getTrackingNo());
            rowUpdated = statement.executeUpdate() > 0;
        }
        return rowUpdated;
    }

    private void printSQLException(SQLException ex) {
        for (Throwable e : ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }
}
