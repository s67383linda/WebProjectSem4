package com.DAO;

import com.Model.UnclaimParcel;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UnclaimParcelDAO {
    private final String jdbcURL = "jdbc:mysql://localhost:3306/parcelmanagementsystem";
    private final String jdbcUsername = "root";
    private final String jdbcPassword = "admin";

    private static final String INSERT_UNCLAIMPARCEL_SQL = "INSERT INTO unclaimparcels (batchID, parcelNo, parcelID, studID) VALUES (?, ?, ?, ?)";
    private static final String SELECT_UNCLAIMPARCEL_BY_BATCHID = "SELECT * FROM unclaimparcels WHERE batchID = ?";
    private static final String SELECT_ALL_UNCLAIMPARCEL = "SELECT * FROM unclaimparcels";
    private static final String DELETE_UNCLAIMPARCEL_SQL = "DELETE FROM unclaimparcels WHERE batchID = ?";
    private static final String UPDATE_UNCLAIMPARCEL_SQL = "UPDATE unclaimparcels SET batchID = ?, parcelNo = ?, parcelID = ?, studID = ? WHERE batchID = ?";

    public UnclaimParcelDAO() {}

    protected Connection getConnection() {
        Connection connection = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return connection;
    }

    public void insertUnclaimParcel(UnclaimParcel unclaimParcel) throws SQLException {
        System.out.println(INSERT_UNCLAIMPARCEL_SQL);
        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_UNCLAIMPARCEL_SQL)) {
            preparedStatement.setInt(1, unclaimParcel.getBatchID());
            preparedStatement.setString(2, unclaimParcel.getParcelNo());
            preparedStatement.setString(3, unclaimParcel.getParcelID());
            preparedStatement.setString(4, unclaimParcel.getStudID());
            System.out.println(preparedStatement);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            printSQLException(e);
        }
    }

    public UnclaimParcel selectUnclaimParcel(int batchID) {
        UnclaimParcel unclaimParcel = null;
        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_UNCLAIMPARCEL_BY_BATCHID)) {
            preparedStatement.setInt(1, batchID);
            System.out.println(preparedStatement);
            ResultSet rs = preparedStatement.executeQuery();
            
            while (rs.next()) {
                String parcelNo = rs.getString("parcelNo");
                String parcelID = rs.getString("parcelID");
                String studID = rs.getString("studID");
                unclaimParcel = new UnclaimParcel(batchID, parcelID, parcelNo, studID);
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return unclaimParcel;
    }

    public List<UnclaimParcel> getAllUnclaimParcels() {
        List<UnclaimParcel> unclaimParcels = new ArrayList<>();
        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_UNCLAIMPARCEL)) {
            System.out.println(preparedStatement);
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                int batchID = rs.getInt("batchID");
                String parcelNo = rs.getString("parcelNo");
                String parcelID = rs.getString("parcelID");
                String studID = rs.getString("studID");
                unclaimParcels.add(new UnclaimParcel(batchID, parcelNo, parcelID, studID));
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return unclaimParcels;
    }

    public boolean deleteUnclaimParcel(int batchID) throws SQLException {
        boolean rowDeleted;
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(DELETE_UNCLAIMPARCEL_SQL)) {
            statement.setInt(1, batchID);
            rowDeleted = statement.executeUpdate() > 0;
        }
        return rowDeleted;
    }

    public boolean updateUnclaimParcel(UnclaimParcel unclaimParcel) throws SQLException {
        boolean rowUpdated;
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(UPDATE_UNCLAIMPARCEL_SQL)) {
            statement.setInt(1, unclaimParcel.getBatchID());
            statement.setString(2, unclaimParcel.getParcelNo());
            statement.setString(3, unclaimParcel.getParcelID());
            statement.setString(4, unclaimParcel.getStudID());
            statement.setInt(5, unclaimParcel.getBatchID());
            rowUpdated = statement.executeUpdate() > 0;
        }
        return rowUpdated;
    }

    private void printSQLException(SQLException ex) {
        for (Throwable e : ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }
}
