package com.DAO;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.Model.ParcelList;

public class ParcelListDAO {

    private String jdbcURL = "jdbc:mysql://localhost:3306/parcelmanagementsystem";
    private String jdbcUsername = "root";
    private String jdbcPassword = "admin";

    private static final String INSERT_PARCEL_SQL = "INSERT INTO parcelList (parcelID, trackingNo, description, charge, weight, deliveredDate, studID) VALUES (?, ?, ?, ?, ?, ?, ?);";
    private static final String SELECT_PARCEL_BY_ID = "SELECT parcelID, trackingNo, description, charge, weight, deliveredDate, studID FROM parcel_list WHERE parcelID = ?;";
    private static final String SELECT_ALL_PARCELS = "SELECT * FROM parcelList;";
    private static final String DELETE_PARCEL_SQL = "DELETE FROM parcelList WHERE parcelID = ?;";
    private static final String UPDATE_PARCEL_SQL = "UPDATE parcelList SET trackingNo = ?, description = ?, charge = ?, weight = ?, deliveredDate = ?, studID = ? WHERE parcelID = ?;";

    protected Connection getConnection() {
        Connection connection = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return connection;
    }

    public void insertParcelList(ParcelList parcelList) throws SQLException {
        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_PARCEL_SQL)) {
            preparedStatement.setString(1, parcelList.getParcelID());
            preparedStatement.setString(2, parcelList.getTrackingNo());
            preparedStatement.setString(3, parcelList.getDescription());
            preparedStatement.setDouble(4, parcelList.getCharge());
            preparedStatement.setDouble(5, parcelList.getWeight());
            preparedStatement.setDate(6, parcelList.getDeliveredDate());
            preparedStatement.setString(7, parcelList.getStudID());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            printSQLException(e);
        }
    }

    public ParcelList selectParcelList(String parcelID) {
        ParcelList parcelList = null;
        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_PARCEL_BY_ID)) {
            preparedStatement.setString(1, parcelID);
            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                String trackingNo = rs.getString("trackingNo");
                String description = rs.getString("description");
                double charge = rs.getDouble("charge");
                double weight = rs.getDouble("weight");
                Date deliveredDate = rs.getDate("deliveredDate");
                String studID = rs.getString("studID");
                parcelList = new ParcelList(parcelID, trackingNo, description, charge, weight, deliveredDate, studID);
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return parcelList;
    }

    public List<ParcelList> selectAllParcelList() {
        List<ParcelList> parcels = new ArrayList<>();
        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_PARCELS)) {
            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                String parcelID = rs.getString("parcelID");
                String trackingNo = rs.getString("trackingNo");
                String description = rs.getString("description");
                double charge = rs.getDouble("charge");
                double weight = rs.getDouble("weight");
                Date deliveredDate = rs.getDate("deliveredDate");
                String studID = rs.getString("studID");
                parcels.add(new ParcelList(parcelID, trackingNo, description, charge, weight, deliveredDate, studID));
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return parcels;
    }

    public boolean deleteParcelList(String parcelID) throws SQLException {
        boolean rowDeleted;
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(DELETE_PARCEL_SQL)) {
            statement.setString(1, parcelID);
            rowDeleted = statement.executeUpdate() > 0;
        }
        return rowDeleted;
    }

    public boolean updateParcelList(ParcelList parcelList) throws SQLException {
        boolean rowUpdated;
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(UPDATE_PARCEL_SQL)) {
            statement.setString(1, parcelList.getTrackingNo());
            statement.setString(2, parcelList.getDescription());
            statement.setDouble(3, parcelList.getCharge());
            statement.setDouble(4, parcelList.getWeight());
            statement.setDate(5, parcelList.getDeliveredDate());
            statement.setString(6, parcelList.getStudID());
            statement.setString(7, parcelList.getParcelID());

            rowUpdated = statement.executeUpdate() > 0;
        }
        return rowUpdated;
    }

    private void printSQLException(SQLException ex) {
        for (Throwable e : ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }
}
